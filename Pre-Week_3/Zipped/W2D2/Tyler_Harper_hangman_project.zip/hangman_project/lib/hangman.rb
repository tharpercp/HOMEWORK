class Hangman
  DICTIONARY = ["cat", "dog", "bootcamp", "pizza"]

  def self.random_word
    DICTIONARY.sample
  end

  def initialize
    @secret_word = Hangman.random_word
    @attempted_chars = []
    @remaining_incorrect_guesses = 5
    @guess_word = Array.new(@secret_word.length, "_")
  end

  def guess_word
    @guess_word
  end

  def attempted_chars
    @attempted_chars
  end

  def remaining_incorrect_guesses
    @remaining_incorrect_guesses
  end

  def already_attempted?(char)
    if attempted_chars.include?(char)
      return true
    end
  false
  end

  def get_matching_indices(char)
    answer = []
    @secret_word.each_char.with_index do |x, i|
      if x == char
        answer << i
      end
    end
  answer
  end

  def fill_indices(char, arr)
    arr.each { |x| @guess_word[x] = char }
  end

  def try_guess(char)
    if self.already_attempted?(char)
      puts "that has already been attempted"
      return false
    end

    @attempted_chars << char

    matches = self.get_matching_indices(char)

    if matches == []
      @remaining_incorrect_guesses -= 1
    end

    self.fill_indices(char, matches)
    true

  end

  def ask_user_for_guess
    p "Enter a char:"
    char = gets.chomp
    self.try_guess(char)
  end

  def win?
    if @guess_word.join("") == @secret_word
      p "WIN"
      return true
    else
      false
    end
  end

  def lose?
    if @remaining_incorrect_guesses == 0
      p "LOSE"
      true
    else
      false
    end
  end

  def game_over?
    if self.win? || self.lose?
      p @secret_word
      true
    else
      false
    end
  end

end