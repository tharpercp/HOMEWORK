require_relative "room"

class Hotel
    def initialize(name, capacities)
        @name = name
        @rooms = Hash.new(0)
        capacities.each do |room_name, capacity|
            @rooms[room_name] = Room.new(capacity)
        end

    end

    def name
        @name.split(" ").map(&:capitalize).join(" ")
    end

    def rooms
        @rooms
    end

    def room_exists?(str)
        if @rooms.has_key?(str)
            true
        else
            false
        end
    end
    
    def check_in(person, room_name)
        if self.room_exists?(room_name)
            if @rooms[room_name].add_occupant(person)
                puts "check in successful"
                true
            else
                puts "sorry, room is full"
                false
            end 
        else
            puts "sorry, room does not exist"
        end
    end

    def has_vacancy?
        @rooms.each do |room_name, capacity|
            if @rooms[room_name].available_space != 0
                return true
            end
        end
    false
    end

    def list_rooms
        @rooms.each do |room_name, room|
            puts "#{room_name} :#{room.available_space}"
        end
    end


end
