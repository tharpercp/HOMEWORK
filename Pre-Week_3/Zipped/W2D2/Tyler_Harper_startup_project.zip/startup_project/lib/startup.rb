require "employee"

class Startup

    def initialize(name, funding, salaries)
        @name = name
        @funding = funding
        @employees = []
        @salaries = salaries

    end

    def name
        @name 
    end

    def funding
        @funding 
    end

    def salaries
        @salaries 
    end

    def employees
        @employees
    end

    def valid_title?(str)
        if @salaries.has_key?(str)
            return true
        end
    false
    end

    def >(startup_1)
        if @funding > startup_1.funding 
            return true
        else 
            return false
        end
    end

    def hire(ename, title1)
        if !@salaries.has_key?(title1)
            raise "Title is invalid"
        else
            @employees << Employee.new(ename, title1)
        end
    end

    def size
        @employees.length
    end

    def pay_employee(emp)
        paycheck = @salaries[emp.title]
        if @funding >= paycheck
            emp.pay(paycheck)
            @funding -= paycheck
        else
            raise "Not enough funding"
        end
    end

    def payday
        @employees.each do |x|
            pay_employee(x)
        end
    end

    def average_salary
        total = 0
        @employees.each do |x|
            total += @salaries[x.title]
        end
    total / @employees.length
    end

    def close
        @employees = []
        @funding = 0
    end

    def acquire(startup1)
        @funding += startup1.funding
        startup1.salaries.each do |x, y|
            if !@salaries.has_key?(x)
                @salaries[x] = y
            end
        end
        @employees += startup1.employees
        startup1.close
    end 




            
        


end
