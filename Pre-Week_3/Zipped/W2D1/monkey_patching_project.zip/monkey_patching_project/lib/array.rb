# Monkey-Patch Ruby's existing Array class to add your own custom methods
class Array
    def span
        if self == []
            return nil
        else
            return self.max - self.min 
        end
    end

    def average
        if self.length > 0
            return self.sum / (self.length * 1.00)
        else
            return nil
        end
    end

    def median
        sorted = self.sort
        if self.length < 1
            return nil
        elsif self.length % 2 == 0
            return ((sorted[(self.length / 2)] + sorted[(self.length / 2) - 1]) / 2.0)
        else 
            return sorted[(self.length / 2)]
        end
    end

    def counts
        answer = Hash.new(0)
        self.each do |x|
            if !answer.has_key?(x)
                answer[x] = self.count(x)
            end
        end
    answer
    end

    # PART 2

    def my_count(x)
        counter = 0
        self.each { |num| counter += 1 if num == x }
        counter
    end

    def my_index(x)
        self.each.with_index do |num, i|
            if num == x
                return i
            end
        end
    nil
    end

    def my_uniq
        answer = []
        self.each { |num| answer << num if !answer.include?(num) }
        answer
    end

    def my_transpose
        self.map.with_index { |arr, i1| arr.map.with_index { |ele, i2| ele = self[i2][i1] } }
    end 
        



            
end


