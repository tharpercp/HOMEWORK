def element_count(arr)
    answer = Hash.new(0)
    arr.each { |ele| answer[ele] = arr.count(ele) }
    answer
end

def char_replace!(str, hash)
    str.each_char.with_index do |char, i|
        if hash.has_key?(char)
            str[i] = hash[char]
        end
    end
str
end

def product_inject(arr)
    answer = arr.inject { |product, el| product * el }
    answer 
end 