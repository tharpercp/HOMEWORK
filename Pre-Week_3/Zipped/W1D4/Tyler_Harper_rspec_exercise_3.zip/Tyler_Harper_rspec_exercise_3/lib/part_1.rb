def is_prime?(x)
    if x < 2
        return false
    else
        (2...x).each do |n|
            if x % n == 0
                return false
            end
        end
    end
return true
end

def nth_prime(n)
    answer = []
    test = 2
    while answer.length < n
        if is_prime?(test)
            answer << test
            test += 1
        else
            test += 1
        end
    end
answer[-1]
end

def prime_range(min, max)
    answer = []
    i = -1
    while min <= max
        if is_prime?(min)
            answer << min
            min += 1
        else
            min += 1
        end
    end
answer
end
    